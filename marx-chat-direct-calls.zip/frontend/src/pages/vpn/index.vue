<template>
  <div class="page page-vpn-redirect">
    <div class="hint">Перенаправляю...</div>
  </div>
</template>

<script src="./script.ts" lang="ts"/>
<style src="./style.less" lang="less" scoped/>
