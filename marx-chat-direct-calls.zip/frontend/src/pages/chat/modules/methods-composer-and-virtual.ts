import {
  nextTick,
  ws,
  wsObject,
  MENTION_TAG_RE,
  VIRTUAL_MAX_ITEMS,
  VIRTUAL_OVERSCAN,
  VIRTUAL_ESTIMATED_ITEM_HEIGHT,
  COLOR_HEX_FULL_RE,
  COMPOSER_NAMED_COLORS,
  COMPOSER_EMOJIS,
  DONATION_BADGE_FADE_MS,
} from './shared';
import type {
  Message,
  User,
  NotificationItem,
} from './shared';
import {resolveMediaUrl} from '@/composables/media-url';
export const chatMethodsComposerAndVirtual = {
    isDirectDialogUnread(this: any, roomIdRaw: unknown) {
      const roomId = Number(roomIdRaw || 0);
      if (!Number.isFinite(roomId) || roomId <= 0) return false;
      return !!this.unreadDirectDialogIds?.[roomId];
    },

    estimateMessageHeight(this: any, message: Message) {
      const known = Number(this.virtualMessageHeights?.[message.id] || 0);
      if (known > 0) return known;
      return VIRTUAL_ESTIMATED_ITEM_HEIGHT;
    },

    rebuildVirtualPrefix(this: any) {
      if (!this.messages.length) {
        this.virtualPrefixHeights = [0];
        this.virtualTotalHeight = 0;
        return;
      }

      const prefix = new Array(this.messages.length + 1);
      prefix[0] = 0;
      for (let index = 0; index < this.messages.length; index += 1) {
        prefix[index + 1] = prefix[index] + this.estimateMessageHeight(this.messages[index]);
      }

      this.virtualPrefixHeights = prefix;
      this.virtualTotalHeight = prefix[prefix.length - 1] || 0;
    },

    findMessageIndexByOffset(this: any, offsetRaw: number) {
      const total = this.messages.length;
      if (!total) return 0;

      const prefix = this.virtualPrefixHeights;
      if (!Array.isArray(prefix) || prefix.length !== total + 1) {
        return 0;
      }

      const totalHeight = Number(this.virtualTotalHeight || 0);
      const offset = Math.max(0, Number(offsetRaw || 0));
      if (offset <= 0) return 0;
      if (offset >= totalHeight) return total - 1;

      let left = 0;
      let right = total - 1;
      while (left <= right) {
        const middle = (left + right) >> 1;
        const rowTop = Number(prefix[middle] || 0);
        const rowBottom = Number(prefix[middle + 1] || rowTop);
        if (offset < rowTop) {
          right = middle - 1;
          continue;
        }
        if (offset >= rowBottom) {
          left = middle + 1;
          continue;
        }
        return middle;
      }

      return Math.max(0, Math.min(total - 1, left));
    },

    syncVirtualWindowFromScroll(this: any) {
      const total = this.messages.length;
      if (!total) {
        this.virtualRangeStart = 0;
        this.virtualRangeEnd = 0;
        this.virtualPrefixHeights = [0];
        this.virtualTotalHeight = 0;
        return;
      }

      this.rebuildVirtualPrefix();
      if (total <= VIRTUAL_MAX_ITEMS || !this.messagesEl) {
        this.virtualRangeStart = 0;
        this.virtualRangeEnd = total;
        return;
      }

      const scrollTop = Math.max(0, Number(this.messagesEl.scrollTop || 0));
      const viewportBottom = scrollTop + Math.max(1, Number(this.messagesEl.clientHeight || 1));
      const firstVisible = this.findMessageIndexByOffset(scrollTop);
      const lastVisible = this.findMessageIndexByOffset(Math.max(0, viewportBottom - 1));

      let start = Math.max(0, firstVisible - VIRTUAL_OVERSCAN);
      let end = Math.min(total, start + VIRTUAL_MAX_ITEMS);

      const requiredEnd = Math.min(total, lastVisible + 1 + VIRTUAL_OVERSCAN);
      if (end < requiredEnd) {
        end = requiredEnd;
        start = Math.max(0, end - VIRTUAL_MAX_ITEMS);
      }

      this.virtualRangeStart = start;
      this.virtualRangeEnd = end;
    },

    scheduleVirtualSync(this: any) {
      if (this.virtualSyncScheduled) return;
      this.virtualSyncScheduled = true;

      const run = () => {
        this.virtualSyncScheduled = false;
        this.syncVirtualWindowFromScroll();
      };

      if (typeof window === 'undefined') {
        run();
        return;
      }
      window.requestAnimationFrame(run);
    },

    pruneVirtualHeightMap(this: any) {
      const current = this.virtualMessageHeights || {};
      const activeIds = new Set(this.messages.map((message: Message) => Number(message.id)));
      const next: Record<number, number> = {};

      for (const [idRaw, valueRaw] of Object.entries(current)) {
        const id = Number.parseInt(idRaw, 10);
        if (!Number.isFinite(id) || !activeIds.has(id)) continue;
        const value = Number(valueRaw || 0);
        if (value <= 0) continue;
        next[id] = value;
      }

      this.virtualMessageHeights = next;
    },

    notifyMessagesChanged(this: any) {
      this.pruneVirtualHeightMap();
      this.scheduleVirtualSync();
      this.syncScriptableRuntimes();
    },

    onVirtualItemHeight(this: any, messageIdRaw: unknown, heightRaw: unknown) {
      const messageId = Number.parseInt(String(messageIdRaw ?? ''), 10);
      const height = Math.max(24, Math.round(Number(heightRaw || 0)));
      if (!Number.isFinite(messageId) || !Number.isFinite(height) || height <= 0) return;

      const prev = Number(this.virtualMessageHeights?.[messageId] || 0);
      if (prev > 0 && Math.abs(prev - height) < 2) return;

      this.virtualMessageHeights = {
        ...this.virtualMessageHeights,
        [messageId]: height,
      };
      this.scheduleVirtualSync();
    },

    normalizeColor(this: any, raw: string) {
      const value = String(raw || '').trim();
      if (!value) return '';
      return value.toLowerCase();
    },

    formatUsername(this: any, nicknameRaw: unknown) {
      const nickname = String(nicknameRaw || '').trim();
      if (!nickname) return '';
      return `@${nickname}`;
    },

    isSystemNickname(this: any, nicknameRaw: unknown) {
      return String(nicknameRaw || '').trim().toLowerCase() === 'marx';
    },

    isSystemUser(this: any, user: User | null) {
      return this.isSystemNickname(user?.nickname);
    },

    parseDonationBadgeUntilTs(this: any, raw: unknown) {
      const value = String(raw || '').trim();
      if (!value) return 0;
      const ts = Date.parse(value);
      return Number.isFinite(ts) ? ts : 0;
    },

    getDonationBadgeOpacity(this: any, raw: unknown) {
      const untilTs = this.parseDonationBadgeUntilTs(raw);
      if (!untilTs) return 0;

      const nowTs = Number(this.badgeNowTs || Date.now());
      const remaining = untilTs - nowTs;
      if (remaining <= 0) return 0;
      if (remaining >= DONATION_BADGE_FADE_MS) return 1;
      return Math.max(0, Math.min(1, remaining / DONATION_BADGE_FADE_MS));
    },

    hasDonationBadge(this: any, user: User | null) {
      return this.getDonationBadgeOpacity(user?.donationBadgeUntil) > 0;
    },

    getDonationBadgeStyle(this: any, user: User | null) {
      return {
        opacity: this.getDonationBadgeOpacity(user?.donationBadgeUntil),
      };
    },

    hasMessageAuthorDonationBadge(this: any, message: Message) {
      return this.getDonationBadgeOpacity(message?.authorDonationBadgeUntil) > 0;
    },

    getMessageAuthorDonationBadgeOpacity(this: any, message: Message) {
      return this.getDonationBadgeOpacity(message?.authorDonationBadgeUntil);
    },

    hasNotificationAuthorDonationBadge(this: any, notification: NotificationItem) {
      return this.getDonationBadgeOpacity(notification?.authorDonationBadgeUntil) > 0;
    },

    getNotificationAuthorDonationBadgeStyle(this: any, notification: NotificationItem) {
      return {
        opacity: this.getDonationBadgeOpacity(notification?.authorDonationBadgeUntil),
      };
    },

    getUserNameStyle(this: any, user: User | null) {
      if (!user?.nicknameColor) return {};
      return {color: user.nicknameColor};
    },

    getAuthorStyle(this: any, message: Message) {
      if (!message.authorNicknameColor) return {};
      return {color: message.authorNicknameColor};
    },

    normalizeMessage(this: any, message: any): Message {
      const sourceKind = String(message?.kind || 'text').trim().toLowerCase();
      const rawText = String(message?.rawText ?? message?.body ?? '');
      const fallbackText = rawText.trim() || '[scriptable disabled]';
      const renderedPreviews = Array.isArray(message?.renderedPreviews) ? message.renderedPreviews : [];
      const runtimeRaw = message?.runtime && typeof message.runtime === 'object' && !Array.isArray(message.runtime)
        ? message.runtime
        : {};
      const runtimeData = runtimeRaw?.data && typeof runtimeRaw.data === 'object' && !Array.isArray(runtimeRaw.data)
        ? runtimeRaw.data
        : {};
      const commentRoomId = Number(message?.commentRoomId || 0);
      return {
        ...message,
        kind: sourceKind === 'system' ? 'system' : 'text',
        rawText: sourceKind === 'scriptable' ? fallbackText : rawText,
        authorAvatarUrl: resolveMediaUrl(message?.authorAvatarUrl) || null,
        authorDonationBadgeUntil: message?.authorDonationBadgeUntil
          ? String(message.authorDonationBadgeUntil)
          : null,
        renderedHtml: sourceKind === 'scriptable'
          ? String(message?.renderedHtml || fallbackText)
          : String(message?.renderedHtml ?? ''),
        renderedPreviews,
        runtime: {
          clientScript: null,
          serverScript: null,
          data: sourceKind === 'scriptable' ? {} : runtimeData,
        },
        commentRoomId: Number.isFinite(commentRoomId) && commentRoomId > 0 ? commentRoomId : null,
        commentCount: Math.max(0, Number(message?.commentCount || 0)),
        reactions: Array.isArray(message?.reactions) ? message.reactions : [],
      } as Message;
    },

    async onMessageAuthorAvatarClick(this: any, messageRaw: Message) {
      const message = this.normalizeMessage(messageRaw);
      const nickname = String(message?.authorNickname || '').trim();
      const authorId = Number(message?.authorId || 0);
      if (!nickname || !Number.isFinite(authorId) || authorId <= 0) return;
      if (nickname.toLowerCase() === 'anonymous') return;

      this.hapticTap();
      await this.router.push({
        path: '/console',
        query: {
          tab: 'user',
          nickname,
        },
      });
    },

    getMessageRawText(this: any, messageRaw: any) {
      return String(messageRaw?.rawText ?? messageRaw?.body ?? '');
    },

    resetMessagePreviewCache(this: any) {
      // server-side rendering: no frontend message html/preview cache
    },

    formatMessageTime(this: any, createdAt: string) {
      const date = new Date(createdAt);
      if (Number.isNaN(date.getTime())) return '00:00:00';

      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      const seconds = String(date.getSeconds()).padStart(2, '0');
      return `${hours}:${minutes}:${seconds}`;
    },

    focusMessageInputToEnd(this: any) {
      nextTick(() => {
        const input = this.messageInputEl as HTMLTextAreaElement | null;
        if (!input) return;
        input.focus();
        const offset = input.value.length;
        input.setSelectionRange(offset, offset);
      });
    },

    appendToInput(this: any, text: string) {
      const current = String(this.messageText || '');
      const needsSpace = current.length > 0 && !/\s$/.test(current);
      this.messageText = needsSpace ? `${current} ${text}` : `${current}${text}`;
      this.focusMessageInputToEnd();
    },

    composerNamedColors(this: any) {
      return COMPOSER_NAMED_COLORS;
    },

    composerEmojis(this: any) {
      return COMPOSER_EMOJIS;
    },

    toggleComposerTools(this: any) {
      this.hapticTap();
      this.composerToolsOpen = !this.composerToolsOpen;
      if (this.composerToolsOpen) {
        this.captureActiveComposerInputSelection();
      }
    },

    closeComposerTools(this: any) {
      this.composerToolsOpen = false;
    },

    captureInputSelection(this: any) {
      const input = this.messageInputEl as HTMLTextAreaElement | null;
      if (!input) return;
      const start = Number.isFinite(input.selectionStart) ? Number(input.selectionStart) : 0;
      const end = Number.isFinite(input.selectionEnd) ? Number(input.selectionEnd) : start;
      this.composerSelectionStart = Math.max(0, start);
      this.composerSelectionEnd = Math.max(this.composerSelectionStart, end);
      this.activeComposerInputTarget = 'main';
    },

    captureEditInputSelection(this: any, message: Message, event: Event) {
      if (Number(this.editingMessageId || 0) <= 0) return;
      if (Number(message?.id || 0) !== Number(this.editingMessageId || 0)) return;
      const input = event.target as HTMLTextAreaElement | null;
      if (!input) return;
      const start = Number.isFinite(input.selectionStart) ? Number(input.selectionStart) : 0;
      const end = Number.isFinite(input.selectionEnd) ? Number(input.selectionEnd) : start;
      this.editSelectionStart = Math.max(0, start);
      this.editSelectionEnd = Math.max(this.editSelectionStart, end);
      this.activeComposerInputTarget = 'edit';
    },

    captureActiveComposerInputSelection(this: any) {
      const active = document.activeElement as HTMLTextAreaElement | null;
      if (active && active.classList?.contains('message-edit-input') && Number(this.editingMessageId || 0) > 0) {
        const start = Number.isFinite(active.selectionStart) ? Number(active.selectionStart) : 0;
        const end = Number.isFinite(active.selectionEnd) ? Number(active.selectionEnd) : start;
        this.editSelectionStart = Math.max(0, start);
        this.editSelectionEnd = Math.max(this.editSelectionStart, end);
        this.activeComposerInputTarget = 'edit';
        return;
      }
      const messageInput = this.messageInputEl as HTMLTextAreaElement | null;
      if (active && messageInput && active === messageInput) {
        this.captureInputSelection();
        return;
      }
      if (Number(this.editingMessageId || 0) > 0) {
        this.activeComposerInputTarget = 'edit';
        return;
      }
      this.captureInputSelection();
    },

    getEditMessageInput(this: any) {
      return document.querySelector('.message-edit-input') as HTMLTextAreaElement | null;
    },

    resolveActiveComposerInputTarget(this: any): 'main' | 'edit' {
      if (Number(this.editingMessageId || 0) <= 0) return 'main';
      const active = document.activeElement as HTMLElement | null;
      if (active?.classList?.contains('message-edit-input')) return 'edit';
      if (active?.classList?.contains('input')) return 'main';
      return this.activeComposerInputTarget === 'edit' ? 'edit' : 'main';
    },

    getMessageInputRange(this: any) {
      const textLength = String(this.messageText || '').length;
      const input = this.messageInputEl as HTMLTextAreaElement | null;
      const inputFocused = !!input && document.activeElement === input;
      const activeStart = inputFocused && Number.isFinite(input.selectionStart) ? Number(input.selectionStart) : null;
      const activeEnd = inputFocused && Number.isFinite(input.selectionEnd) ? Number(input.selectionEnd) : null;
      const startBase = activeStart !== null ? activeStart : Number(this.composerSelectionStart || 0);
      const endBase = activeEnd !== null ? activeEnd : Number(this.composerSelectionEnd || startBase);
      const start = Math.min(Math.max(0, startBase), textLength);
      const end = Math.min(Math.max(start, endBase), textLength);
      return {start, end};
    },

    getEditInputRange(this: any) {
      const textLength = String(this.editingMessageText || '').length;
      const input = this.getEditMessageInput();
      const inputFocused = !!input && document.activeElement === input;
      const activeStart = inputFocused && Number.isFinite(input.selectionStart) ? Number(input.selectionStart) : null;
      const activeEnd = inputFocused && Number.isFinite(input.selectionEnd) ? Number(input.selectionEnd) : null;
      const startBase = activeStart !== null ? activeStart : Number(this.editSelectionStart || 0);
      const endBase = activeEnd !== null ? activeEnd : Number(this.editSelectionEnd || startBase);
      const start = Math.min(Math.max(0, startBase), textLength);
      const end = Math.min(Math.max(start, endBase), textLength);
      return {start, end};
    },

    setMessageInputSelection(this: any, startRaw: number, endRaw: number) {
      const start = Math.max(0, Number(startRaw || 0));
      const end = Math.max(start, Number(endRaw || start));
      this.composerSelectionStart = start;
      this.composerSelectionEnd = end;

      nextTick(() => {
        const input = this.messageInputEl as HTMLTextAreaElement | null;
        if (!input) return;
        input.focus();
        input.setSelectionRange(start, end);
      });
    },

    setEditInputSelection(this: any, startRaw: number, endRaw: number) {
      const start = Math.max(0, Number(startRaw || 0));
      const end = Math.max(start, Number(endRaw || start));
      this.editSelectionStart = start;
      this.editSelectionEnd = end;

      nextTick(() => {
        const input = this.getEditMessageInput();
        if (!input) return;
        input.focus();
        input.setSelectionRange(start, end);
      });
    },

    applyWrapperToSelection(this: any, prefixRaw: string, suffixRaw = ')') {
      const prefix = String(prefixRaw || '');
      const suffix = String(suffixRaw || '');
      if (!prefix) return;

      const target = this.resolveActiveComposerInputTarget();
      const current = target === 'edit'
        ? String(this.editingMessageText || '')
        : String(this.messageText || '');
      const {start, end} = target === 'edit'
        ? this.getEditInputRange()
        : this.getMessageInputRange();
      const selected = current.slice(start, end);
      const next = `${current.slice(0, start)}${prefix}${selected}${suffix}${current.slice(end)}`;
      if (target === 'edit') {
        this.editingMessageText = next;
      } else {
        this.messageText = next;
      }
      const hasSelection = end > start;
      const cursorStart = start + prefix.length;
      const cursorEnd = hasSelection ? cursorStart + selected.length : cursorStart;
      if (target === 'edit') {
        this.setEditInputSelection(cursorStart, cursorEnd);
      } else {
        this.setMessageInputSelection(cursorStart, cursorEnd);
      }
    },

    applyNamedColorWrapper(this: any, colorNameRaw: unknown) {
      this.hapticTap();
      const colorName = String(colorNameRaw || '').trim().toLowerCase();
      if (!colorName) return;
      this.applyWrapperToSelection(`c#${colorName}(`);
      this.closeComposerTools();
    },

    applyCustomColorWrapper(this: any) {
      this.hapticTap();
      const color = String(this.composerColorPicker || '').trim();
      if (!COLOR_HEX_FULL_RE.test(color)) {
        this.closeComposerTools();
        return;
      }
      const normalized = color.toUpperCase();
      this.composerColorPicker = normalized;
      this.applyWrapperToSelection(`c${normalized}(`);
      this.closeComposerTools();
    },

    applyFormatWrapper(this: any, tagRaw: unknown) {
      this.hapticTap();
      const tag = String(tagRaw || '').trim().toLowerCase();
      if (!['b', 'u', 's', 'h', 'm'].includes(tag)) {
        this.closeComposerTools();
        return;
      }
      this.applyWrapperToSelection(`${tag}(`);
      this.closeComposerTools();
    },

    insertComposerText(this: any, textRaw: unknown) {
      const insertText = String(textRaw ?? '');
      if (!insertText) return;

      const target = this.resolveActiveComposerInputTarget();
      const current = target === 'edit'
        ? String(this.editingMessageText || '')
        : String(this.messageText || '');
      const {start, end} = target === 'edit'
        ? this.getEditInputRange()
        : this.getMessageInputRange();
      const next = `${current.slice(0, start)}${insertText}${current.slice(end)}`;
      if (target === 'edit') {
        this.editingMessageText = next;
      } else {
        this.messageText = next;
      }
      const cursor = start + insertText.length;
      if (target === 'edit') {
        this.setEditInputSelection(cursor, cursor);
      } else {
        this.setMessageInputSelection(cursor, cursor);
      }
    },

    onComposerEmojiClick(this: any, emojiRaw: unknown) {
      this.hapticTap();
      const emoji = String(emojiRaw || '');
      if (!emoji) {
        this.closeComposerTools();
        return;
      }
      this.insertComposerText(emoji);
      this.closeComposerTools();
    },

    openGalleryPicker(this: any) {
      const input = this.galleryInputEl as HTMLInputElement | null;
      if (!input) {
        this.closeComposerTools();
        return;
      }
      this.hapticTap();
      this.closeComposerTools();
      input.click();
    },

    async attachMediaFiles(this: any, filesRaw: File[]) {
      const files = Array.isArray(filesRaw) ? filesRaw : [];
      if (!files.length) return;
      if (!this.activeDialog || this.pasteUploading) return;

      this.pasteUploading = true;
      this.error = '';

      try {
        for (const sourceFile of files) {
          const preparedFile = await this.prepareUploadMediaFile(sourceFile);
          if (!preparedFile) {
            this.error = 'Файл слишком большой.';
            continue;
          }

          const uploadResult = await this.uploadMediaFile(preparedFile);
          if (!(uploadResult as any)?.ok || !(uploadResult as any)?.url) {
            const uploadError = String((uploadResult as any)?.error || '').toLowerCase();
            this.error = uploadError.includes('file_too_large')
              ? 'Файл слишком большой.'
              : 'Не удалось загрузить файл.';
            continue;
          }

          const url = String((uploadResult as any).url || '').trim();
          if (!url) {
            this.error = 'Не удалось загрузить файл.';
            continue;
          }

          this.appendToInput(url);
        }
      } finally {
        this.pasteUploading = false;
        this.focusMessageInputToEnd();
      }
    },

    async onGalleryInputChange(this: any, event: Event) {
      const input = event.target as HTMLInputElement | null;
      const files = input?.files ? Array.from(input.files) : [];
      if (!files.length) {
        if (input) input.value = '';
        return;
      }

      await this.attachMediaFiles(files);
      if (input) input.value = '';
    },

    async copyTextToClipboard(this: any, textRaw: unknown) {
      const text = String(textRaw ?? '');
      if (!text.trim()) return;

      try {
        if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(text);
        } else {
          const textarea = document.createElement('textarea');
          textarea.value = text;
          textarea.setAttribute('readonly', 'true');
          textarea.style.position = 'fixed';
          textarea.style.opacity = '0';
          textarea.style.pointerEvents = 'none';
          document.body.appendChild(textarea);
          textarea.focus();
          textarea.select();
          document.execCommand('copy');
          document.body.removeChild(textarea);
        }
        this.pushToast('Буфер обмена', 'Код скопирован');
      } catch {
        this.error = 'Не удалось скопировать код.';
      }
    },

    onAuthorClick(this: any, message: Message) {
      this.hapticTap();
      this.appendToInput(`${this.formatUsername(message.authorNickname)}, `);
    },

    onMessageTimeClick(this: any, message: Message) {
      this.hapticTap();
      this.appendToInput(`${this.formatUsername(message.authorNickname)} [${this.formatMessageTime(message.createdAt)}], `);
    },

    canOpenDirectFromMessage(this: any, message: Message) {
      if (!this.me) return false;
      if (this.activeDialog?.kind === 'direct') return false;
      if (Number(message.authorId || 0) <= 0) return false;
      if (String(message.authorNickname || '').trim().toLowerCase() === 'anonymous') return false;
      return this.me.id !== message.authorId;
    },

    canOpenDiscussionFromMessage(this: any, message: Message) {
      if (!this.activeDialog) return false;
      if (this.activeDialog.kind === 'direct') return false;
      if (this.activeDialog.commentsEnabled === false) return false;
      const messageId = Number(message?.id || 0);
      return Number.isFinite(messageId) && messageId > 0;
    },

    applyMessageCommentRoomId(this: any, messageIdRaw: unknown, commentRoomIdRaw: unknown) {
      const messageId = Number(messageIdRaw || 0);
      const commentRoomId = Number(commentRoomIdRaw || 0);
      if (!Number.isFinite(messageId) || messageId <= 0) return;
      const nextCommentRoomId = Number.isFinite(commentRoomId) && commentRoomId > 0
        ? commentRoomId
        : null;

      this.messages = this.messages.map((item: Message) => {
        if (Number(item.id || 0) !== messageId) return item;
        return {
          ...item,
          commentRoomId: nextCommentRoomId,
        };
      });

      if (Number(this.activePinnedMessage?.id || 0) === messageId) {
        this.activePinnedMessage = {
          ...this.activePinnedMessage,
          commentRoomId: nextCommentRoomId,
        };
      }
    },

    buildDiscussionRouteContext(this: any, sourceMessageIdRaw: unknown) {
      const sourceMessageId = Number(sourceMessageIdRaw || 0);
      return {
        sourceRoomId: Number(this.activeDialog?.id || 0) || null,
        sourceMessageId: Number.isFinite(sourceMessageId) && sourceMessageId > 0
          ? sourceMessageId
          : null,
      };
    },

    async openMessageDiscussion(this: any, message: Message) {
      if (!this.canOpenDiscussionFromMessage(message)) return;
      if (this.discussionOpenPendingMessageId) return;

      const messageId = Number(message.id || 0);
      if (!Number.isFinite(messageId) || messageId <= 0) return;

      this.hapticTap();
      this.discussionOpenPendingMessageId = messageId;
      try {
        let commentRoomId = Number(message.commentRoomId || 0);
        if (Number.isFinite(commentRoomId) && commentRoomId > 0) {
          const current = await ws.request('message:comment-room:get', {messageId});
          if (!(current as any)?.ok) {
            commentRoomId = 0;
          } else {
            commentRoomId = Number(wsObject(current).commentRoomId || 0);
          }
        }

        if (!Number.isFinite(commentRoomId) || commentRoomId <= 0) {
          const result = await ws.request('message:comment-room:create', {messageId});
          if (!(result as any)?.ok) {
            this.error = (result as any)?.error === 'comments_disabled'
              ? 'Комментарии в этой комнате отключены.'
              : 'Не удалось открыть комментарии.';
            return;
          }

          const data = wsObject(result);
          commentRoomId = Number(data.commentRoomId || 0);
          if (!Number.isFinite(commentRoomId) || commentRoomId <= 0) {
            this.error = 'Не удалось открыть комментарии.';
            return;
          }

          const updatedMessageRaw = data.message;
          if (updatedMessageRaw && typeof updatedMessageRaw === 'object') {
            this.applyMessageUpdate(updatedMessageRaw);
          } else {
            this.applyMessageCommentRoomId(messageId, commentRoomId);
          }
          await this.fetchDirectDialogs();
        }

        const path = this.buildRoomRoutePath(
          commentRoomId,
          this.buildDiscussionRouteContext(messageId),
        );
        await this.router.push(path);
      } finally {
        this.discussionOpenPendingMessageId = null;
      }
    },

    async onBackToDiscussionSource(this: any) {
      const discussion = this.activeDialog?.discussion;
      if (!discussion) return;
      this.hapticTap();

      const sourceRoomId = Number(discussion.sourceRoomId || 0);
      const sourceMessageId = Number(discussion.sourceMessageId || 0);
      if (!Number.isFinite(sourceRoomId) || sourceRoomId <= 0) {
        this.pushToast('Комментарии', 'Исходный пост удалён');
        return;
      }

      const path = this.buildRoomRoutePath(sourceRoomId, {
        focusMessageId: Number.isFinite(sourceMessageId) && sourceMessageId > 0
          ? sourceMessageId
          : null,
      });
      await this.router.push(path);
    },

    async onDirectFromMessageClick(this: any, message: Message) {
      if (!this.canOpenDirectFromMessage(message)) return;
      this.hapticTap();
      await this.selectPrivate({
        id: message.authorId,
        nickname: message.authorNickname,
        name: message.authorName,
        nicknameColor: message.authorNicknameColor,
        donationBadgeUntil: message.authorDonationBadgeUntil || null,
      } as User, {haptic: false});
    },

    isOwnMessage(this: any, message: Message) {
      return this.me?.id === message.authorId;
    },

    startMessageEdit(this: any, message: Message) {
      if (!this.isOwnMessage(message)) return;
      if (message.kind !== 'text') return;
      this.hapticTap();
      this.editingMessageId = message.id;
      this.editingMessageText = this.getMessageRawText(message);
      this.activeComposerInputTarget = 'edit';
      this.editSelectionStart = String(this.editingMessageText || '').length;
      this.editSelectionEnd = this.editSelectionStart;
      this.reactionPickerMessageId = null;
      this.reactionTooltipVisible = false;
      nextTick(() => {
        const input = document.querySelector('.message-edit-input') as HTMLTextAreaElement | null;
        if (!input) return;
        input.focus();
        const offset = input.value.length;
        input.setSelectionRange(offset, offset);
      });
    },

    cancelMessageEdit(this: any) {
      this.editingMessageId = null;
      this.editingMessageText = '';
      this.editSelectionStart = 0;
      this.editSelectionEnd = 0;
      this.activeComposerInputTarget = 'main';
    },

    onEditingMessageTextUpdate(this: any, valueRaw: unknown) {
      this.editingMessageText = String(valueRaw ?? '');
    },

    applyMessageUpdate(this: any, messageRaw: any) {
      const message = this.normalizeMessage(messageRaw);
      this.messages = this.messages.map((item: Message) => {
        if (item.id !== message.id || item.roomId !== message.roomId) return item;
        return message;
      });
      this.resetMessagePreviewCache();
      this.notifyMessagesChanged();
    },

    applyMessageDelete(this: any, roomId: number, messageId: number) {
      if (this.editingMessageId === messageId) {
        this.cancelMessageEdit();
      }
      if (Number(this.activePinnedMessage?.id || 0) === Number(messageId || 0)) {
        this.activePinnedMessage = null;
      }
      if (this.reactionPickerMessageId === messageId) {
        this.reactionPickerMessageId = null;
      }
      this.messages = this.messages.filter((message: Message) => {
        return !(message.roomId === roomId && message.id === messageId);
      });
      if (this.scriptMessageViewModels?.[messageId]) {
        const nextViews = {...(this.scriptMessageViewModels || {})};
        delete nextViews[messageId];
        this.scriptMessageViewModels = nextViews;
      }
      this.resetMessagePreviewCache();
      this.notifyMessagesChanged();
      this.updateScrollDownVisibility();
    },

    async saveMessageEdit(this: any, message: Message) {
      if (!this.isOwnMessage(message)) return;
      if (message.kind !== 'text') return;
      this.hapticTap();
      const body = String(this.editingMessageText || '').trim();
      if (!body) {
        this.error = 'Сообщение не может быть пустым.';
        return;
      }

      this.messageActionPendingId = message.id;
      try {
        const result = await ws.request('message:update', {
          messageId: message.id,
          text: body,
        });
        if (!(result as any)?.ok) {
          this.error = 'Не удалось отредактировать сообщение.';
          return;
        }

        this.applyMessageUpdate(wsObject(result).message);
        this.cancelMessageEdit();
      } finally {
        this.messageActionPendingId = null;
      }
    },

    async deleteOwnMessage(this: any, message: Message) {
      if (!this.isOwnMessage(message)) return;
      this.hapticTap();
      if (!window.confirm('Удалить это сообщение?')) return;

      this.messageActionPendingId = message.id;
      try {
        const result = await ws.request('message:delete', {messageId: message.id});
        if (!(result as any)?.ok) {
          this.error = 'Не удалось удалить сообщение.';
          return;
        }

        const data = wsObject(result);
        this.applyMessageDelete(data.roomId, data.messageId);
        await this.fetchDirectDialogs();
      } finally {
        this.messageActionPendingId = null;
      }
    },

    onEditMessageKeydown(this: any, event: KeyboardEvent, message: Message) {
      if (event.key !== 'Enter' || (!event.ctrlKey && !event.metaKey)) return;
      event.preventDefault();
      void this.saveMessageEdit(message);
    },

    extractMentionTokens(this: any, bodyRaw: unknown) {
      const body = String(bodyRaw || '');
      const tokens: string[] = [];
      MENTION_TAG_RE.lastIndex = 0;
      for (const match of body.matchAll(MENTION_TAG_RE)) {
        const nickname = String(match[1] || '').trim().toLowerCase();
        if (!nickname) continue;
        tokens.push(nickname);
      }
      return tokens;
    },

    hasMentionToken(this: any, bodyRaw: unknown, nicknameRaw: unknown) {
      const mentionToken = String(nicknameRaw || '').trim().toLowerCase();
      if (!mentionToken) return false;
      return this.extractMentionTokens(bodyRaw).includes(mentionToken);
    },

    containsAllKeyword(this: any, body: string) {
      return this.hasMentionToken(body, 'all');
    },

    isMyNameMentionTokenUnique(this: any) {
      const myNameToken = String(this.me?.name || '').trim().toLowerCase();
      if (!myNameToken) return false;
      const duplicates = (this.users || []).some((user: User) => {
        if (Number(user.id || 0) === Number(this.me?.id || 0)) return false;
        return String(user.name || '').trim().toLowerCase() === myNameToken;
      });
      return !duplicates;
    },

    isMentionedForMe(this: any, message: Message) {
      const meNickname = String(this.me?.nickname || '').toLowerCase();
      if (message.authorId === this.me?.id) return false;
      const rawText = this.getMessageRawText(message);
      if (this.containsAllKeyword(rawText)) return true;
      if (!meNickname) return false;
      if (this.hasMentionToken(rawText, meNickname)) return true;

      if (!this.isMyNameMentionTokenUnique()) return false;
      const myNameToken = String(this.me?.name || '').trim().toLowerCase();
      if (!myNameToken) return false;
      return this.hasMentionToken(rawText, myNameToken);
    },
};
